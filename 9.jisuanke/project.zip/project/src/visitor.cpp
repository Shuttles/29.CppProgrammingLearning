#include "visitor.h"
//TODO
void ExpressionPointer::Visit(NumberExpression* node)
{
	
}


void ExpressionPointer::Visit(BinaryExpression* node)
{
	
}
