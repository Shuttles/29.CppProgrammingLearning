
#include "Visitor.h"
void ExprPointer::Visit(NumberExpr* node)
{
	//TODO
}
void ExprPointer::Visit(IdExpr* node)
{
	//TODO
}
void ExprPointer::Visit(BinaryExpr* node)
{
	//TODO
}
void ExprPointer::Visit(InvokeExpr* node)
{
	//TODO
}