#include "handler.h"
#include <cstdlib>
bool IdHandler::Test(string token, bool forInvoke)
{
    if (forInvoke == true) return false;
    if (token.length() <= 0) return false;
    
}
shared_ptr<Expr> IdHandler::IdFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	share_ptr<IdExper> expr = make_shared<IdExpr>();
    expr->name = token;
    return expr;
}

shared_ptr<Expr> NumberHandler::NumberFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	shared_ptr<NumberExpr> expr = make_shared<NumberExpr>();\
    expr->number = 0;
    for (auto x : token) {
        exper->number += expr->numer * 10 + (x - '0');
    }
    return expr;
}
bool NumberHandler::Test(string token, bool forInvoke)
{
	//TODO
}

bool BinaryHandler::Test(string token, bool forInvoke)
{
	//TODO
}
shared_ptr<Expr>BinaryHandler::BinaryFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	shared_ptr<BinaryExpr> expr = make_shared<BinaryExpr>();
    switch(token[0]) {
            
    }
}

shared_ptr<Expr> InvokeHandler::InvokeFactory::CreateExpr(string token, vector<shared_ptr<Expr>>arguments)
{
	shared_ptr<InvokeExpr> expr = make_shared<InvokeExpr>();
    expr->name = token;
    for (auto x : arguments) {
        expr->arguments.push_back(x);
    }
    return expr;
}
bool InvokeHandler::Test(string token, bool forInvoke)
{
	//TODO
}

